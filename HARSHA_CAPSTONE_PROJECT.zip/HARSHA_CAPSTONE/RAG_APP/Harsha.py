import streamlit as st
from langchain_community.document_loaders import WebBaseLoader, PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import Chroma
from langchain_ollama import OllamaLLM, OllamaEmbeddings
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
import tempfile

# Streamlit Configuration
st.set_page_config(page_title="Small Scale RAG App", layout="wide")
st.title("🌐 Harsha's Simple RAG Q&A Assistant")

# User Inputs
urls = st.text_input("🔗 Enter a URL (or multiple, comma-separated):")
pdf = st.file_uploader("📄 Or upload a PDF", type=["pdf"])
question = st.text_input("💬 Ask your question:")

# Temporary directory for Chroma
CHROMA_DIR = tempfile.mkdtemp()

# Function: Load Documents
def load_docs(urls, pdf):
    results = []
    if urls:
        for u in urls.split(","):
            u = u.strip()
            if u:
                results.extend(WebBaseLoader(u).load())
    if pdf:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(pdf.read())
            loader = PyPDFLoader(tmp.name)
            results.extend(loader.load())
    return results

# Function: Split Documents
def split_documents(results):
    splitter = RecursiveCharacterTextSplitter(chunk_size=1500, chunk_overlap=200)
    splits = splitter.split_documents(results)
    return splits

# Function: Create Vectorstore
@st.cache_resource(show_spinner=True)
def create_vectorstore(documents):
    embeddings = OllamaEmbeddings(model="embeddinggemma:300m")
    vectordb = Chroma.from_documents(
        documents=documents,
        embedding=embeddings,
        persist_directory=CHROMA_DIR
    )
    return vectordb.as_retriever(search_kwargs={"k": 6})

# Function: Prompt Template
def prompt_function(question, documents):
    return PromptTemplate(
        input_variables=["question", "documents"],
        template="""
        You are a strict assistant for document-based Q&A.
        
        You have access ONLY to the text provided from the user's uploaded PDFs or URLs.
        Do NOT use any general knowledge or external information.

        Instructions:
        1. Answer the user's question ONLY if it can be found in the provided documents.
        2. If the answer is not in the documents, respond EXACTLY with: "I don't know".
        3. Do NOT make guesses or add information not in the documents.
        4. Keep your answer concise (50-100 words max).

        User Question: {question}
        Document Content: {documents}

        Answer:
        """
    )

# Function: Create LLM Chain
def create_llm_chain(question, results):
    llm = OllamaLLM(model="llama3.2:1b", temperature=0)
    prompt = prompt_function(question, results)
    chain = prompt | llm | StrOutputParser()
    return chain

# Main Process Button
if st.button("⚙️ Process Documents"):
    if question.strip().lower() in ["who are you", "your name", "how are you"]:
        st.write("I'm Harsha's Simple RAG Q&A Assistant — always ready to help with your uploaded knowledge sources! 😉")
    elif not urls and not pdf:
        st.error("Please provide at least one URL or upload a PDF.")
    else:
        st.write("🔄 Processing your documents...")
        results = load_docs(urls, pdf)
        splits = split_documents(results)
        retriever = create_vectorstore(splits)
        chain = create_llm_chain(question, results)
        st.session_state["rag"] = (retriever, chain)
        st.success("✅ Documents processed and stored successfully in Chroma!")
        
# Question & Answer Section
if "rag" in st.session_state and question:
    retriever, chain = st.session_state["rag"]
    with st.spinner("🤔 Generating your answer..."):
        docs = retriever.invoke(question)
        context = "\n".join(d.page_content for d in docs)
        answer = chain.invoke({"question": question, "documents": context})
    clean_answer = answer.strip()
    if not clean_answer or "i don't know" in clean_answer.lower():
        st.write("I don't know")
    else:
        st.write(clean_answer)
